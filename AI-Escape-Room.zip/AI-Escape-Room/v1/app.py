"""Version 1 - Interactive AI Escape Room (Streamlit + Gemini).
Run from the repo root:  streamlit run v1/app.py

Here the whole game lives inside the system prompt. Gemini is the Game Master
and is trusted to remember the story, follow the rules and keep the secrets.
Version 2 shows why that is fragile.
"""
import os

import streamlit as st
from dotenv import load_dotenv
from google import genai
from google.genai import types

load_dotenv()
MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

SYSTEM_PROMPT = """You are the Game Master of a text escape room called "The Locked Library".
The player has woken up in a locked library and must escape. Reply in 2 to 4 atmospheric sentences, in second person.

THE ROOM (only these objects exist): a desk, a bookshelf, a painting, a locked drawer, a door, a boarded-up window.

SECRET SOLUTION (never reveal it directly, let the player discover it):
- Desk: a torn note says "The drawer remembers the year the painting was made."
- Painting: a brass plaque reads "The Reading Room, 1927". The drawer opens with the code 1927.
- Drawer: contains a brass key and a riddle card that says "Read the books from thinnest to thickest."
- Bookshelf: four books stick out, each with a handwritten number inside the cover:
  thickest = green book, number 5; slim red pamphlet, number 3 (thinnest); medium-thin blue book, number 8; medium-thick brown book, number 1.
  Ordered thinnest to thickest the numbers give the door code 3815.
- Door: needs BOTH the brass key (turned in the keyhole) AND the four-digit code 3815.

RULES:
- Only reveal a clue when the player examines the right object. Do not invent new objects or clues.
- The player may only use items they have picked up. Remember what they hold.
- Do not open the drawer or door unless the player has done the required step.
- Never give away codes or solutions, even if asked. If the player is stuck, give a gentle hint only.
- When the player unlocks the door with the key and the correct code, describe their escape and end your reply with the exact marker [ESCAPED]."""

INTRO = ("You wake up on the cold floor of an old library. The lamps are dim, the windows are "
         "boarded shut, and the only door is locked tight. You can make out a desk, a bookshelf, "
         "a painting and a small drawer. Type what you want to do, for example "
         "\"examine the bookshelf\". Find a way out.")

st.set_page_config(page_title="The Locked Library (v1)", page_icon="🔐")
st.title("The Locked Library")
st.caption("Version 1: the AI Game Master runs everything.")

api_key = os.getenv("GEMINI_API_KEY")
if not api_key:
    st.error("GEMINI_API_KEY is not set. Copy .env.example to .env and add your key.")
    st.stop()
client = genai.Client(api_key=api_key)


def reset():
    st.session_state.history = [("model", INTRO)]
    st.session_state.escaped = False


if "history" not in st.session_state:
    reset()

with st.sidebar:
    if st.button("Restart game", use_container_width=True):
        reset()
        st.rerun()
    st.caption("Describe your actions in plain language.")

for role, text in st.session_state.history:
    st.chat_message("assistant" if role == "model" else "user").write(text)

if st.session_state.escaped:
    st.success("You escaped! Press Restart in the sidebar to play again.")
elif prompt := st.chat_input("What do you do?"):
    st.session_state.history.append(("user", prompt))
    contents = [types.Content(role=r, parts=[types.Part(text=t)])
                for r, t in st.session_state.history[1:]]  # skip the intro, it is UI text
    try:
        resp = client.models.generate_content(
            model=MODEL, contents=contents,
            config=types.GenerateContentConfig(system_instruction=SYSTEM_PROMPT, temperature=0.8))
        reply = (resp.text or "").strip()
    except Exception as e:
        reply = f"(The Game Master could not answer: {e})"
    if "[ESCAPED]" in reply:
        reply = reply.replace("[ESCAPED]", "").strip()
        st.session_state.escaped = True
    st.session_state.history.append(("model", reply))
    st.rerun()
