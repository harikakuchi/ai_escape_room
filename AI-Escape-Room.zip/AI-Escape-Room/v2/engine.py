"""Game engine for Version 2.

Everything that decides what is true in the game lives here, in plain Python:
the game state, the rules and the action validation. No LLM is called in this
file. The LLM only rewrites the engine's result as prose (see llm.py).
"""
import json
import re
from pathlib import Path

CONFIG_PATH = Path(__file__).with_name("game_config.json")

ALLOWED_ACTIONS = {
    "examine", "take", "use", "enter_code", "inventory",
    "help", "hint", "refuse", "claim_solved", "unknown",
}


def load_config(path=CONFIG_PATH):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def new_state():
    """The complete game state. This dict is the single source of truth."""
    return {
        "found": [],        # items the player has discovered but not taken yet
        "inventory": [],    # items the player is carrying
        "seen": [],         # clues the player has looked at: "plaque", "books"
        "solved": [],       # puzzles solved: "drawer", "door"
        "drawer_locked": True,
        "key_turned": False,
        "door_locked": True,
        "escaped": False,
        "attempts": {"drawer": 0, "door": 0},
        "turns": 0,
    }


# ---------------------------------------------------------------- name lookup

def find_refs(cfg, text):
    """Return [(kind, id), ...] for every known object or item named in text,
    in the order they appear. Longer names win ('brass key' beats 'key')."""
    text = (text or "").lower().replace("_", " ")
    hits = []
    for kind, table in (("object", cfg["objects"]), ("item", cfg["items"])):
        for key, info in table.items():
            for alias in info["aliases"] + [key.replace("_", " ")]:
                for m in re.finditer(r"\b%s\b" % re.escape(alias), text):
                    hits.append((m.start(), m.end(), kind, key))
    hits.sort(key=lambda h: -(h[1] - h[0]))
    claimed, chosen = [], []
    for start, end, kind, key in hits:
        if any(start < ce and cs < end for cs, ce in claimed):
            continue
        claimed.append((start, end))
        chosen.append((start, kind, key))
    chosen.sort()
    return [(kind, key) for _, kind, key in chosen]


def _first_ref(cfg, text, kind=None):
    for k, key in find_refs(cfg, text):
        if kind is None or k == kind:
            return k, key
    return None


def _res(ok, facts, changed=False, event=""):
    return {"ok": ok, "facts": facts, "changed": changed, "event": event}


def _add(lst, value):
    if value not in lst:
        lst.append(value)


# -------------------------------------------------------------------- actions

def apply_action(cfg, state, action):
    """Validate one action against the state and apply it if it is allowed.
    Returns {"ok", "facts", "changed", "event"}. Never raises on bad input."""
    state["turns"] += 1
    kind = action.get("action", "unknown")
    if kind not in ALLOWED_ACTIONS:
        kind = "unknown"
    if state["escaped"] and kind not in ("inventory", "help"):
        return _res(True, cfg["messages"]["already_escaped"], event="already_escaped")
    handlers = {
        "examine": _examine, "take": _take, "use": _use,
        "enter_code": _enter_code, "inventory": _inventory,
        "help": _help, "hint": _hint, "refuse": _refuse,
        "claim_solved": _claim_solved, "unknown": _unknown,
    }
    return handlers[kind](cfg, state, action)


def _examine(cfg, state, action):
    msg, txt = cfg["messages"], cfg["text"]
    target = action.get("target") or ""
    ref = _first_ref(cfg, target)
    if ref is None:
        if re.search(r"\b(room|around|surroundings|library)\b", target.lower()):
            return _res(True, msg["overview"], event="overview")
        return _res(False, msg["not_here"], event="examine_unknown")
    kind, key = ref

    if kind == "item":
        if key in state["inventory"]:
            return _res(True, txt["item_" + key], event="read_" + key)
        if key in state["found"]:
            name = cfg["items"][key]["name"]
            return _res(True, msg["take_first"].format(item=name), event="item_not_taken")
        # Hidden items must not be confirmed to exist.
        return _res(False, msg["not_here"], event="examine_hidden")

    if key == "desk":
        if "torn_note" in state["inventory"]:
            return _res(True, txt["desk_after_take"], event="examine_desk")
        _add(state["found"], "torn_note")
        return _res(True, txt["desk_first"], True, "examine_desk")
    if key == "painting":
        _add(state["seen"], "plaque")
        return _res(True, txt["painting"], True, "examine_painting")
    if key == "bookshelf":
        _add(state["seen"], "books")
        return _res(True, txt["bookshelf"], True, "examine_bookshelf")
    if key == "drawer":
        if state["drawer_locked"]:
            return _res(True, txt["drawer_locked"], event="examine_drawer")
        left = [cfg["items"][k]["name"] for k in ("brass_key", "riddle_card")
                if k in state["found"] and k not in state["inventory"]]
        if left:
            return _res(True, txt["drawer_open"].format(items=" and ".join(left)),
                        event="examine_drawer")
        return _res(True, txt["drawer_empty"], event="examine_drawer")
    if key == "door":
        text = txt["door_key_turned"] if state["key_turned"] else txt["door_locked"]
        return _res(True, text, event="examine_door")
    return _res(True, txt["window"], event="examine_window")


def _take(cfg, state, action):
    msg = cfg["messages"]
    ref = _first_ref(cfg, action.get("target") or "")
    if ref is None:
        return _res(False, msg["not_here"], event="take_unknown")
    kind, key = ref
    if kind == "object":
        return _res(False, msg["cant_take"], event="take_object")
    if key in state["inventory"]:
        return _res(False, msg["already_have"], event="take_duplicate")
    if key not in state["found"]:
        return _res(False, msg["not_here"], event="take_hidden")
    state["found"].remove(key)
    state["inventory"].append(key)
    return _res(True, msg["taken"].format(item=cfg["items"][key]["name"]),
                True, "take_" + key)


def _use(cfg, state, action):
    msg = cfg["messages"]
    item_text = action.get("item") or ""
    if not item_text.strip():
        return _res(False, msg["use_what"], event="use_missing_item")
    item = _first_ref(cfg, item_text, "item")
    if item is None or item[1] not in state["inventory"]:
        return _res(False, msg["no_item"], event="use_not_owned")
    target = _first_ref(cfg, action.get("target") or "", "object")
    if target is None:
        return _res(False, msg["use_on_what"], event="use_missing_target")
    if (item[1], target[1]) == ("brass_key", "door"):
        if state["key_turned"]:
            return _res(False, msg["key_already"], event="key_already")
        state["key_turned"] = True
        return _res(True, msg["key_turned"], True, "key_turned")
    return _res(False, msg["nothing_happens"], event="use_no_effect")


def _enter_code(cfg, state, action):
    msg, sol = cfg["messages"], cfg["solutions"]
    code = re.sub(r"\D", "", str(action.get("code") or ""))
    target = _first_ref(cfg, action.get("target") or "", "object")
    if target is None:
        return _res(False, msg["ask_target"], event="code_no_target")
    key = target[1]
    if key not in ("drawer", "door"):
        return _res(False, msg["no_lock"], event="code_no_lock")
    if len(code) != 4:
        return _res(False, msg["bad_code"], event="code_bad_format")

    if key == "drawer":
        if not state["drawer_locked"]:
            return _res(False, msg["drawer_open_already"], event="drawer_already_open")
        if code != sol["drawer_code"]:
            state["attempts"]["drawer"] += 1
            return _res(False, msg["drawer_wrong"], True, "drawer_wrong_code")
        state["drawer_locked"] = False
        _add(state["solved"], "drawer")
        _add(state["found"], "brass_key")
        _add(state["found"], "riddle_card")
        return _res(True, msg["drawer_opened"], True, "drawer_unlocked")

    # door
    if not state["key_turned"]:
        return _res(False, msg["keypad_dead"], event="door_needs_key")
    if code != sol["door_code"]:
        state["attempts"]["door"] += 1
        return _res(False, msg["door_wrong"], True, "door_wrong_code")
    state["door_locked"] = False
    state["escaped"] = True
    _add(state["solved"], "door")
    return _res(True, msg["escape"], True, "escaped")


def _inventory(cfg, state, action):
    if not state["inventory"]:
        return _res(True, cfg["messages"]["inventory_empty"], event="inventory")
    names = ", ".join(cfg["items"][k]["name"] for k in state["inventory"])
    return _res(True, cfg["messages"]["inventory"].format(items=names), event="inventory")


def _help(cfg, state, action):
    return _res(True, cfg["messages"]["help"], event="help")


def _hint(cfg, state, action):
    h = cfg["hints"]
    inv = state["inventory"]
    if state["drawer_locked"]:
        if "torn_note" not in inv:
            k = "desk"
        elif "plaque" not in state["seen"]:
            k = "painting"
        else:
            k = "dial"
    elif "brass_key" not in inv or "riddle_card" not in inv:
        k = "take_items"
    elif "books" not in state["seen"]:
        k = "books"
    elif not state["key_turned"]:
        k = "key"
    else:
        k = "code"
    return _res(True, h[k], event="hint")


def _refuse(cfg, state, action):
    return _res(False, cfg["messages"]["refuse"], event="refused")


def _claim_solved(cfg, state, action):
    """The player says something is already solved. We only trust the state."""
    msg = cfg["messages"]
    target = _first_ref(cfg, action.get("target") or "", "object")
    if target and target[1] == "drawer":
        key = "claim_drawer_open" if not state["drawer_locked"] else "claim_drawer_locked"
    elif target and target[1] == "door":
        key = "claim_door_locked"
    else:
        key = "claim_generic"
    return _res(False, msg[key], event="claim_rejected")


def _unknown(cfg, state, action):
    return _res(False, cfg["messages"]["unknown"], event="unknown")


def progress(cfg, state):
    """Small summary for the sidebar."""
    return {
        "inventory": [cfg["items"][k]["name"] for k in state["inventory"]],
        "drawer": "open" if not state["drawer_locked"] else "locked",
        "door": "open" if not state["door_locked"] else ("key turned" if state["key_turned"] else "locked"),
        "turns": state["turns"],
    }
