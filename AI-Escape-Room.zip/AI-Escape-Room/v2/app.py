"""Version 2 - Reliable AI Escape Room (Streamlit).
Run from the repo root:  streamlit run v2/app.py
"""
import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).parent))
import engine  # noqa: E402
import game  # noqa: E402
import llm  # noqa: E402

st.set_page_config(page_title="The Locked Library (v2)", page_icon="🔐")


@st.cache_resource
def get_cfg():
    return engine.load_config()


@st.cache_resource
def get_client():
    try:
        return llm.get_client()
    except Exception:
        return None


cfg, client = get_cfg(), get_client()


def reset():
    st.session_state.state = engine.new_state()
    st.session_state.log = []
    st.session_state.messages = [("assistant", cfg["intro"] + "\n\n" + cfg["messages"]["help"])]


if "state" not in st.session_state:
    reset()
state = st.session_state.state

st.title(cfg["title"])
st.caption("Version 2: the game rules and state live in Python, the AI only describes what happens.")

with st.sidebar:
    if st.button("Restart game", use_container_width=True):
        reset()
        st.rerun()
    p = engine.progress(cfg, state)
    st.subheader("Progress")
    st.write("Inventory: " + (", ".join(p["inventory"]) or "empty"))
    st.write(f"Drawer: {p['drawer']}")
    st.write(f"Door: {p['door']}")
    st.write(f"Turns: {p['turns']}")
    st.caption("AI mode: Gemini" if client else "AI mode: offline (no GEMINI_API_KEY, using built-in text)")
    with st.expander("Engine log"):
        for entry in reversed(st.session_state.log[-8:]):
            st.json(entry)

for role, content in st.session_state.messages:
    st.chat_message(role).write(content)

if state["escaped"]:
    st.success("You escaped! Press Restart in the sidebar to play again.")
    if st.session_state.pop("celebrate", False):
        st.balloons()
elif prompt := st.chat_input("What do you do?"):
    st.session_state.messages.append(("user", prompt))
    with st.spinner("The Game Master is thinking..."):
        turn = game.play_turn(cfg, state, prompt, client)
    st.session_state.messages.append(("assistant", turn["reply"]))
    st.session_state.log.append({
        "you_said": prompt, "parsed_by": turn["source"], "action": turn["action"],
        "event": turn["result"]["event"], "ok": turn["result"]["ok"]})
    if state["escaped"]:
        st.session_state.celebrate = True
    st.rerun()
