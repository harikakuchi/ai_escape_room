"""Rule-based parsing and input guards for Version 2.

Two jobs:
1. is_meta(): spot attempts to talk to the game system instead of playing
   (admin claims, 'ignore your rules', 'tell me the code'). These never reach
   the LLM and never reach the engine as real actions.
2. parse(): a keyword parser that turns a message into an action dict. It is
   the fallback when the LLM is unavailable, and it is what the unit tests use.
3. sanitize_action(): treats LLM output as untrusted and forces it into the
   action schema.
"""
import re

from engine import ALLOWED_ACTIONS, find_refs

META_PATTERNS = [
    r"\badmin(istrator)?\b",
    r"\bdeveloper\b",
    r"\bsystem prompt\b",
    r"\b(ignore|forget|disregard)\b.{0,25}\b(rules|instructions|prompt)\b",
    r"\boverride\b",
    r"\bjailbreak\b",
    r"\bpretend\b",
    r"\bdebug mode\b",
    r"\b(reveal|show|tell|give|list|print|spoil)\b.{0,25}\b(secrets?|codes?|solutions?|answers?|passwords?)\b",
    r"\bwhat('s| is| are) the (secret |door |drawer )?(codes?|solutions?|answers?)\b",
]
CLAIM_PATTERN = r"\b(already|previously|earlier)\b.{0,30}\b(solved|unlocked|opened|done|found|got)\b|\bi (have )?solved\b"


def is_meta(text):
    t = (text or "").lower()
    return any(re.search(p, t) for p in META_PATTERNS)


def _act(action, **kw):
    out = {"action": action, "target": None, "item": None, "code": None}
    out.update(kw)
    return out


def parse(cfg, text):
    t = (text or "").strip().lower()
    if not t:
        return _act("unknown")
    if is_meta(t):
        return _act("refuse")
    if re.search(CLAIM_PATTERN, t):
        return _act("claim_solved", target=t)
    if re.search(r"\b(inventory|what do i (have|carry)|my items|pockets?)\b", t):
        return _act("inventory")
    if re.search(r"\bhints?\b|\bi('m| am) stuck\b|\bwhat (should|do) i do\b", t):
        return _act("hint")
    if re.search(r"\b(help|instructions|how (do i|to) play|commands)\b", t):
        return _act("help")

    m = re.search(r"\b(\d{4})\b", t)
    if m:
        return _act("enter_code", target=t, code=m.group(1))

    refs = find_refs(cfg, t)
    if re.search(r"\b(take|grab|pick up|collect|pocket|get)\b", t):
        return _act("take", target=t)
    if re.search(r"\b(use|insert|turn|unlock|put)\b", t):
        item = next((k for kind, k in refs if kind == "item"), None)
        obj = next((k for kind, k in refs if kind == "object"), None)
        return _act("use", item=item, target=obj)
    if re.search(r"\b(examine|look|inspect|check|read|search|open|investigate|view|study|see)\b", t) or refs:
        return _act("examine", target=t)
    return _act("unknown")


def sanitize_action(raw):
    """Force untrusted (LLM) output into the action schema."""
    if not isinstance(raw, dict):
        return _act("unknown")
    action = str(raw.get("action", "")).strip().lower()
    if action not in ALLOWED_ACTIONS:
        return _act("unknown")
    out = _act(action)
    for field in ("target", "item"):
        value = raw.get(field)
        out[field] = str(value)[:60] if value else None
    digits = re.sub(r"\D", "", str(raw.get("code") or ""))
    out["code"] = digits[:4] if digits else None
    return out
