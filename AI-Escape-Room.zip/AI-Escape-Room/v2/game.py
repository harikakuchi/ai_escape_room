"""One full turn of Version 2: guard -> intent -> engine -> narration."""
import engine
import llm
from local_parser import is_meta, parse


def play_turn(cfg, state, text, client=None):
    if is_meta(text):
        action, source = {"action": "refuse", "target": None, "item": None, "code": None}, "guard"
    else:
        # Clear commands are handled instantly by the rule parser. Gemini is only
        # asked when the rules cannot tell what the player means.
        action, source = parse(cfg, text), "rules"
        if action["action"] == "unknown" and client:
            llm_action = llm.parse_intent(client, text, cfg)
            if llm_action is not None:
                action, source = llm_action, "llm"

    result = engine.apply_action(cfg, state, action)
    reply = llm.narrate(client, cfg, action, result)
    narrated = reply is not None
    if reply is None:
        reply = result["facts"]
    return {"action": action, "source": source, "result": result,
            "reply": reply, "narrated": narrated}
