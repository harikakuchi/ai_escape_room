# AI Escape Room: Design Report

## 1. What I built

The project is a text escape room called The Locked Library. The player wakes up in a locked room with a desk, a bookshelf, a painting, a drawer, a window and a door, and has to find clues and solve three linked puzzles to get out. I built it in two versions with Streamlit as the interface and Gemini as the LLM. The goal of the second version was to fix the reliability problems that an LLM-only design runs into.

## 2. Version 1: the LLM as the whole game

In Version 1 the entire game is described in one system prompt: the objects, the clue chain, the solutions and the rules. The chat history is sent to Gemini on every turn, and the model decides what happens. I added a marker, `[ESCAPED]`, that the model must output when the player gets out, so the app can show a win message. Restart simply clears the history.

This approach was fast to build and the responses feel natural. The weakness is that nothing is enforced. The rules are only instructions in a prompt, the state exists only as text in the conversation, and the solutions are sitting in the prompt where a determined player might extract them. The assignment lists the failure modes: forgetting past actions, inventing objects, revealing clues early and allowing actions that should not be possible. I designed my test cases around those. When I played Version 1, it handled a fair playthrough well. For example, I entered the door code 3815 before using the key. The model described the code being accepted by the panel but said the latch still held because the door needed a physical key, and it opened only after I used the key. That was correct, but it was the model improvising an order of events: nothing in the app tracks the inventory, the drawer or the door, so I could not see the state, and the same input could be answered differently on another run. In Version 2 the same sequence is enforced by the engine. The keypad stays inactive until the key has been turned, and only then does it ask for the four digits. The sidebar shows the inventory, the drawer and door status and the turn count, so the state can be checked at any time.

## 3. Version 2: Python decides, the LLM describes

The main change is a separation of responsibilities. The game state is a Python dictionary holding the inventory, found items, clues seen, solved puzzles, the drawer and door status and the number of failed attempts. The rules and solutions are stored in `game_config.json`, outside any prompt. A function in `engine.py` takes a structured action and either applies it or rejects it. The LLM is used in two small places only.

First, an intent parser converts the player's sentence into JSON such as `{"action": "use", "item": "brass key", "target": "door"}`. Clear commands are handled by a keyword parser, and Gemini is asked only when the wording is unclear, which keeps most turns fast. Second, a narrator receives the engine's result, including whether it succeeded or failed, and writes a few sentences in the voice of the Game Master.

Several design choices matter for reliability:

- The engine validates everything. A key must be in the inventory before it can be used, the keypad does nothing until the key is turned, a drawer cannot be re-opened, and unknown objects are rejected.
- Hidden items are not confirmed. If the player asks about the riddle card before opening the drawer, the answer is the same as for an object that does not exist.
- LLM output is treated as untrusted. The sanitiser forces the parsed action into a fixed schema, so an invented action like `unlock_exit` becomes `unknown`.
- The narrator never sees the player's raw message or the solutions, so there is nothing for an injection to act on. Its output is also checked, and if it contains a number that was not in the facts it was given, the engine's own text is used instead.
- A small guard catches obvious attacks, such as claiming to be the administrator or asking for the codes, before any LLM call. This is a convenience layer. The real protection is that the engine does not accept claims about state in the first place.
- If there is no API key or a call fails, the engine's built-in text keeps the game playable. I also turned off Gemini's extra reasoning step and added a 10 second timeout, because early versions took several seconds per turn.

## 4. Testing

I wrote offline tests in `tests/test_v2_engine.py` that run the same pipeline as the app. They cover the situations from the assignment (a key that was not collected, a wrong code, a false claim of progress, a fake administrator and a request for the solutions) and several more, for example entering the door code before turning the key, examining things that do not exist, taking an item twice, and a full successful playthrough. All of them pass. The table in `docs/test_cases.md` compares each case with how Version 1 can fail.

## 5. Problems encountered

The hardest design question was where to draw the line between the LLM and Python. If the LLM does too little, the game feels like a fixed menu. If it does too much, the reliability problems come back. Splitting it into understanding the player and describing the outcome gave me natural language on both ends and hard rules in the middle.

A second problem was information leakage through the narrator. Even without the solutions, a model can add details that were not in the facts. The number check and the strict narrator prompt reduce this, but a check on digits does not catch everything, such as a spelled-out number.

## 6. Limitations and future work

The fallback keyword parser misses unusual phrasing. The input guard is pattern-based and can be bypassed with creative wording, although a bypass cannot change the game state. The puzzle flow is partly written in code instead of being fully data-driven, so adding a new room would take some engineering. Next steps would be a generic rule format in the JSON file, several rooms, and an automated adversarial test that sends many injection prompts to the live model.

## 7. Conclusion

Version 1 shows how quickly an LLM can carry a whole interactive game, and Version 2 shows why that is not enough when the game has rules that must hold. Keeping the state and rules in ordinary code, and using the LLM for language, made the game consistent and much harder to break.
